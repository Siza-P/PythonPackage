# my_first_package
This library was created after the process of creating my first python package.

# Steps in creating your own package
1. There must be git and a text editor setup on your machine.
2. Create a directory to use for the package.
3. In your text editor, open the folder.
4. Navigate to text editors workspace, and locate the package.
5. Create new files and subfiles needed for the package.
6. Within the files, input your instructions and functions (with documentation)
7. Import files where necessary
8. Test the functions.
9. Save all your files. (preferably as you code)